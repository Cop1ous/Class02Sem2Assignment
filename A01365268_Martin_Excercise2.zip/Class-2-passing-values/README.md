# Excercise 1
## Created by Cole
## Today in class we covered passing values, global colors, event changes, components, html and css
